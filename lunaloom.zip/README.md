# Jyotish Saathi

A responsive one-page North Indian Jyotish practice website built with Vite, React, and CSS. Its four anchored sections are home, about, services, and contact. Hindi and English appear throughout, with all service names and descriptions in both languages. The visual system pairs ivory, sindoor/maroon, saffron, and brass with a traditional North Indian Kundli chart motif.

## Run locally

```sh
pnpm install
pnpm dev
```

Production output can be built with `pnpm build`.

## Content to personalize

“Jyotish Saathi” and `namaste@jyotishsaathi.example` are sample branding and a reserved example address for this starter. Replace the practice name, booking email, and any consultation information with the practitioner's real details before launch. The inquiry form prepares a draft in the visitor's email client; it does not submit or store the message on a server.

## Stock-image notes

The hero uses the Pexels stock photo “Traditional Diwali Oil Lamp with Marigold Garland” (the search-media asset is [here](https://files.manuscdn.com/search-media/310519664036058343/ZihdpxAnIYbmmdxmU7sQee/hAb6W2Qr2DaYiyWj6uQnN3.jpeg)). The about section uses a Pexels astrology-chart consultation still (search-media asset [here](https://files.manuscdn.com/search-media/310519664036058343/ZihdpxAnIYbmmdxmU7sQee/pcxgYmWZTWKYpWzh422CRd.jpeg)). Both are stored in managed project image storage; chart geometry, borders, and page motifs are native artwork.
