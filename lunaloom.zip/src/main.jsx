import { useEffect, useState } from 'react'
import { createRoot } from 'react-dom/client'
import './styles.css'

const CONTACT_EMAIL = 'namaste@jyotishsaathi.example'
const PHOTO_DIYA = '/manus-storage/diya-marigold_6741cda2.jpg'
const PHOTO_CHART = '/manus-storage/jyotish-chart_12216fa8.jpg'

function KundliMark({ size = 38, className = '' }) {
  return (
    <svg className={className} width={size} height={size} viewBox="0 0 48 48" fill="none" aria-hidden="true">
      <path d="M5 5h38v38H5z" stroke="currentColor" strokeWidth="1.4" />
      <path d="M24 5 43 24 24 43 5 24 24 5Z" stroke="currentColor" strokeWidth="1.25" />
      <path d="m5 5 19 19L43 5M43 43 24 24 5 43" stroke="currentColor" strokeWidth="1.1" />
      <circle cx="24" cy="24" r="2" fill="currentColor" />
    </svg>
  )
}

function Arrow({ up = false }) {
  return up ? (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M8 13V3m0 0L4 7m4-4 4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
  ) : (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M2.5 8h10m0 0L8 3.5M12.5 8 8 12.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
  )
}

function SunIcon({ kind = 'sun' }) {
  const shapes = {
    sun: <><circle cx="24" cy="24" r="8" /><path d="M24 3v6m0 30v6M3 24h6m30 0h6M9.2 9.2l4.2 4.2m21.2 21.2 4.2 4.2m0-29.6-4.2 4.2M13.4 34.6l-4.2 4.2" /></>,
    match: <><path d="M15 8v11a9 9 0 0 0 18 0V8M24 28v13m-8 0h16" /><path d="M15 8h18m-18 0a4 4 0 0 1 8 0m2 0a4 4 0 0 1 8 0" /></>,
    muhurat: <><circle cx="24" cy="24" r="19" /><path d="M24 12v12l9 6M7 24h4m26 0h4M24 5v4" /></>,
  }
  return <svg width="27" height="27" viewBox="0 0 48 48" fill="none" stroke="currentColor" strokeWidth="1.35" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{shapes[kind]}</svg>
}

const readings = [
  {
    number: '01',
    icon: 'sun',
    hindi: 'जन्म कुंडली अध्ययन',
    english: 'Birth Chart Reading',
    transliteration: 'Janam Kundli',
    descriptionHi: 'लग्न, ग्रहों की स्थिति और प्रमुख भावों को समझें—अपने सवालों और जीवन के इस पड़ाव के संदर्भ में।',
    descriptionEn: 'A thoughtful look at your birth chart, grounded in the questions and circumstances you bring.',
    value: 'Birth Chart Reading — जन्म कुंडली अध्ययन',
  },
  {
    number: '02',
    icon: 'match',
    hindi: 'कुंडली मिलान',
    english: 'Marriage Compatibility',
    transliteration: 'Kundli Milan',
    descriptionHi: 'परंपरागत गुण मिलान और आपसी स्वभाव पर संतुलित चर्चा—बिना डर या पक्की भविष्यवाणी के।',
    descriptionEn: 'A tradition-rooted conversation about compatibility and shared expectations, without fear-based predictions.',
    value: 'Marriage Compatibility — कुंडली मिलान',
  },
  {
    number: '03',
    icon: 'muhurat',
    hindi: 'शुभ मुहूर्त परामर्श',
    english: 'Auspicious Timing Consultation',
    transliteration: 'Shubh Muhurat',
    descriptionHi: 'विवाह, गृह प्रवेश या किसी नए आरंभ के लिए तिथि और समय चुनने पर विचारपूर्ण मार्गदर्शन।',
    descriptionEn: 'Thoughtful guidance on choosing a date and time for a wedding, griha pravesh, or a new beginning.',
    value: 'Auspicious Timing — शुभ मुहूर्त परामर्श',
  },
]

function Header() {
  const [menuOpen, setMenuOpen] = useState(false)
  const closeMenu = () => setMenuOpen(false)

  useEffect(() => {
    const onKeyDown = (event) => event.key === 'Escape' && closeMenu()
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [])

  return (
    <header className="site-header">
      <div className="header-inner">
        <a className="brand" href="#home" onClick={closeMenu} aria-label="Jyotish Saathi home">
          <span className="brand__mark"><KundliMark size={39} /></span>
          <span className="brand__copy">
            <span className="brand__name">Jyotish Saathi</span>
            <span className="brand__tag" lang="hi">वैदिक ज्योतिष · सहज परामर्श</span>
          </span>
        </a>
        <button type="button" className="menu-toggle" aria-label={menuOpen ? 'नेविगेशन बंद करें / Close menu' : 'मेन्यू खोलें / Open menu'} aria-expanded={menuOpen} aria-controls="main-navigation" onClick={() => setMenuOpen((open) => !open)}>
          {menuOpen ? <svg width="21" height="21" viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="m5 5 10 10M15 5 5 15" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" /></svg> : <svg width="21" height="21" viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M3 6h14M3 10h14M3 14h14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" /></svg>}
        </button>
        <nav id="main-navigation" className={`main-nav${menuOpen ? ' main-nav--open' : ''}`} aria-label="Main navigation / मुख्य मेन्यू">
          <a href="#about" onClick={closeMenu}><span lang="hi">परिचय</span><small>About</small></a>
          <a href="#services" onClick={closeMenu}><span lang="hi">ज्योतिष सेवाएँ</span><small>Services</small></a>
          <a href="#contact" onClick={closeMenu}><span lang="hi">संपर्क</span><small>Contact</small></a>
          <a className="nav-book" href="#contact" onClick={closeMenu}><span lang="hi">परामर्श पूछें</span><Arrow /></a>
        </nav>
      </div>
    </header>
  )
}

function Hero() {
  return (
    <section className="hero" id="home" aria-labelledby="hero-title">
      <div className="hero__rangoli hero__rangoli--one" aria-hidden="true" />
      <div className="hero__rangoli hero__rangoli--two" aria-hidden="true" />
      <div className="hero__layout">
        <div className="hero__copy">
          <p className="eyebrow eyebrow--light"><span lang="hi">वैदिक ज्योतिष</span><i /> Vedic astrology</p>
          <p className="hero__overline" lang="hi">परंपरा से जुड़ा मार्गदर्शन, आपकी भाषा में</p>
          <h1 id="hero-title" className="display"><span lang="hi">आपकी कुंडली।</span><span className="hero__headline-sub">Your chart, <em>your path.</em></span></h1>
          <p className="hero__lead">ज्योतिष पर एक सहज, विचारपूर्ण बातचीत—आपके सवालों, आपकी परंपरा और आपके अपने निर्णयों का सम्मान करते हुए।</p>
          <p className="hero__translation">A thoughtful reading of your chart, rooted in Jyotish tradition and guided by the questions that matter to you.</p>
          <div className="hero__actions">
            <a className="button button--saffron" href="#services"><span lang="hi">सेवाएँ देखें</span><small>Explore services</small><Arrow /></a>
            <a className="hero__text-link" href="#about"><span lang="hi">हमारा दृष्टिकोण</span><small>Our approach</small></a>
          </div>
          <div className="hero__promise"><KundliMark size={21} /><span><b lang="hi">श्रद्धा, स्पष्टता और सम्मान</b><small>Tradition · clarity · personal choice</small></span></div>
        </div>
        <div className="hero__visual">
          <div className="hero__photo-frame">
            <img src={PHOTO_DIYA} alt="A traditional oil lamp with marigold flowers, photographed in warm light" fetchPriority="high" />
            <div className="hero__image-wash" />
            <div className="hero__chart-stamp"><KundliMark size={48} /><span lang="hi">ज्योतिष<br />परामर्श</span></div>
            <div className="hero__photo-caption"><span lang="hi">शुभ आरंभ</span><span>Guidance for the road ahead</span></div>
          </div>
          <div className="hero__image-edge" aria-hidden="true" />
          <span className="hero__sunburst" aria-hidden="true">✳</span>
        </div>
      </div>
      <div className="hero__bottom-rule"><span lang="hi">ग्रहों की भाषा, अपने जीवन के लिए</span><span>Jyotish for your everyday questions</span></div>
    </section>
  )
}

function About() {
  return (
    <section className="about" id="about" aria-labelledby="about-title">
      <div className="about__layout wrap">
        <div className="about__visual">
          <div className="about__photo-frame">
            <img src={PHOTO_CHART} alt="Hands reviewing printed astrological birth charts on a consultation table" loading="lazy" />
          </div>
          <div className="about__kundli-card" aria-label="A traditional North Indian diamond-format horoscope chart">
            <KundliMark size={92} />
            <span className="about__kundli-caption" lang="hi">जन्मपत्री · जन्म कुंडली</span>
          </div>
          <span className="about__edge-label" lang="hi">ज्योतिष विद्या</span>
        </div>
        <div className="about__content">
          <p className="eyebrow"><span lang="hi">परंपरा, संवेदनशीलता के साथ</span></p>
          <h2 className="section-heading" id="about-title"><span lang="hi">कुंडली एक मार्गदर्शन है,</span> <em>अंतिम फ़ैसला नहीं।</em></h2>
          <p className="about__copy-hi" lang="hi">वैदिक ज्योतिष आत्मचिंतन की एक प्राचीन परंपरा है। आपकी कुंडली को ध्यान से समझें—और उन फैसलों को अपने हाथ में रखें जो आपके हैं।</p>
          <p className="about__copy-en">A Jyotish consultation is a respectful conversation about your chart, your timing, and the questions you bring. The aim is insight—not fear or a fixed prediction.</p>
          <div className="about__values">
            <div><span className="value-dot" /><span><b lang="hi">परंपरा में निहित</b><small>Rooted in Jyotish practice</small></span></div>
            <div><span className="value-dot" /><span><b lang="hi">आपके निर्णयों का सम्मान</b><small>Personal choice comes first</small></span></div>
          </div>
          <a className="text-link" href="#services"><span lang="hi">ज्योतिष सेवाएँ</span><small>Explore consultations</small><Arrow /></a>
        </div>
      </div>
    </section>
  )
}

function Services({ onChoose }) {
  return (
    <section className="services" id="services" aria-labelledby="services-title">
      <div className="services__top-rule" aria-hidden="true"><span /><KundliMark size={25} /><span /></div>
      <div className="wrap">
        <div className="services__heading">
          <div><p className="eyebrow"><span lang="hi">ज्योतिष परामर्श</span><i /> Three ways to begin</p><h2 id="services-title" className="section-heading"><span lang="hi">आपके लिए एक</span> <em>सार्थक परामर्श।</em></h2></div>
          <p className="services__intro" lang="hi">हर सवाल अलग होता है। अपने जीवन और परिस्थिति के अनुसार परामर्श चुनें—या हमसे बात करें।</p>
        </div>
        <div className="services__banner">
          <div className="services__banner-chart"><KundliMark size={73} /></div>
          <div><span lang="hi">बारह भाव · नौ ग्रह · आपकी जन्मपत्री</span><small>12 houses · 9 planets · your birth chart</small></div>
          <div className="services__banner-seal"><span lang="hi">शुभम्</span><small>Jyotish Saathi</small></div>
        </div>
        <div className="offerings">
          {readings.map((reading) => (
            <article className="offering" key={reading.number}>
              <div className="offering__topline"><span>{reading.number}</span><span className="offering__icon"><SunIcon kind={reading.icon} /></span></div>
              <p className="offering__translit">{reading.transliteration}</p>
              <h3><span className="offering__hindi" lang="hi">{reading.hindi}</span><span className="offering__english">{reading.english}</span></h3>
              <p className="offering__description" lang="hi">{reading.descriptionHi}</p>
              <p className="offering__description offering__description--en">{reading.descriptionEn}</p>
              <button className="offering__cta" type="button" onClick={() => onChoose(reading.value)} aria-label={`परामर्श पूछें / Ask about ${reading.english}`}><span lang="hi">इस परामर्श के बारे में पूछें</span><small>Ask about this reading</small><Arrow /></button>
            </article>
          ))}
        </div>
        <p className="services__note"><span lang="hi">ज्योतिष परामर्श व्यक्तिगत चिंतन का माध्यम है; यह चिकित्सा, कानूनी या वित्तीय सलाह का विकल्प नहीं है।</span><small>Astrology consultations support reflection; they do not replace medical, legal, or financial advice.</small></p>
      </div>
    </section>
  )
}

function Contact({ selectedService }) {
  const [status, setStatus] = useState('')

  function handleSubmit(event) {
    event.preventDefault()
    const formData = new FormData(event.currentTarget)
    const name = String(formData.get('name') || '').trim()
    const email = String(formData.get('email') || '').trim()
    const service = String(formData.get('service') || 'First conversation')
    const note = String(formData.get('note') || '').trim()
    const subject = encodeURIComponent(`Jyotish consultation inquiry — ${service}`)
    const body = encodeURIComponent(`Namaste,\n\nMy name is ${name}.\nMy email address is ${email}.\nI am interested in: ${service}.\n\nA little more about what I am looking for:\n${note || 'I would like to know more.'}\n\nThank you.`)
    setStatus('Your email app will open with a draft. This page does not store your details.')
    window.location.href = `mailto:${CONTACT_EMAIL}?subject=${subject}&body=${body}`
  }

  return (
    <section className="contact" id="contact" aria-labelledby="contact-title">
      <div className="contact__mandala" aria-hidden="true"><KundliMark size={280} /></div>
      <div className="contact__layout wrap">
        <div className="contact__content">
          <p className="eyebrow eyebrow--light"><span lang="hi">जब आप तैयार हों</span><i /> When you are ready</p>
          <h2 className="section-heading" id="contact-title"><span lang="hi">आइए, आपकी</span><br /><em>बात से शुरुआत करें।</em></h2>
          <p className="contact__lead" lang="hi">अपना सवाल या जिज्ञासा साझा करें। हम मिलकर तय करेंगे कि कौन-सा परामर्श आपके लिए सही रहेगा।</p>
          <p className="contact__translation">Share what is on your mind. We can start with a conversation and decide together which consultation feels right.</p>
          <div className="contact__details">
            <div className="contact__detail"><span className="contact__detail-icon">✉</span><span><small lang="hi">ईमेल करें</small><a href={`mailto:${CONTACT_EMAIL}`}>{CONTACT_EMAIL}</a></span></div>
            <div className="contact__detail"><span className="contact__detail-icon">◷</span><span><small lang="hi">समय</small><span>By appointment · पूर्व-नियोजित</span></span></div>
          </div>
        </div>
        <div className="booking-card">
          <div className="booking-card__heading"><div><p className="eyebrow"><span lang="hi">परामर्श के लिए</span></p><h3 lang="hi">अपनी बात लिखें</h3><span>Begin with a note</span></div><KundliMark size={34} /></div>
          <form onSubmit={handleSubmit}>
            <div className="form-row">
              <div className="form-field"><label htmlFor="name"><span lang="hi">आपका नाम</span><small>Your name</small></label><input id="name" name="name" type="text" placeholder="नाम / Name" autoComplete="name" required /></div>
              <div className="form-field"><label htmlFor="email"><span lang="hi">ईमेल पता</span><small>Email address</small></label><input id="email" name="email" type="email" placeholder="you@example.com" autoComplete="email" required /></div>
            </div>
            <div className="form-field"><label htmlFor="service"><span lang="hi">किस बारे में जानना चाहेंगे?</span><small>Which consultation interests you?</small></label><select id="service" name="service" defaultValue={selectedService} key={selectedService}><option value="A first conversation">अभी तय नहीं / Not sure yet</option>{readings.map((reading) => <option key={reading.value} value={reading.value}>{reading.hindi} · {reading.english}</option>)}</select></div>
            <div className="form-field"><label htmlFor="note"><span lang="hi">आपकी जिज्ञासा</span><small>Your question (optional)</small></label><textarea id="note" name="note" placeholder="यहाँ लिखें / Write a note…" /></div>
            <button className="button button--maroon" type="submit"><span lang="hi">ईमेल से पूछताछ भेजें</span><small>Send an inquiry</small><Arrow /></button>
            <p className="booking-card__fineprint"><span lang="hi">आपकी जानकारी इस पेज पर जमा नहीं होती।</span> Your email app opens with a draft; this page does not save your information.</p>
            <p className="form-status" role="status" aria-live="polite">{status}</p>
          </form>
        </div>
      </div>
      <footer className="site-footer">
        <a className="site-footer__brand" href="#home"><KundliMark size={24} /><span><b>Jyotish Saathi</b><small lang="hi">ज्योतिष साथी</small></span></a>
        <span className="site-footer__motto" lang="hi">श्रद्धा · स्पष्टता · आपका निर्णय</span>
        <a className="site-footer__top" href="#home"><span lang="hi">ऊपर जाएँ</span><Arrow up /></a>
      </footer>
    </section>
  )
}

function App() {
  const [selectedService, setSelectedService] = useState('A first conversation')

  function chooseService(value) {
    setSelectedService(value)
    window.setTimeout(() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 0)
  }

  return <><a className="skip-link" href="#main-content">मुख्य सामग्री पर जाएँ / Skip to content</a><Header /><main id="main-content"><Hero /><About /><Services onChoose={chooseService} /><Contact selectedService={selectedService} /></main></>
}

createRoot(document.getElementById('root')).render(<App />)
